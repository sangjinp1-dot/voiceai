[VoiceAI v1.2.0 최종 보완 요청]

이 ZIP 기준으로 아래 확인 후 APK 빌드해주세요.

필수:
- npm install
- npx expo start 오류 확인
- eas build -p android --profile preview
- eas build -p android --profile production

확인:
- 설정 화면에 OpenAI 제거
- Gemini/ElevenLabs만 표시
- API 키 SecureStore 저장
- 오류 메시지 raw json 노출 최소화
- ElevenLabs multilingual_v2 사용
- Voice Clone 탭 작동
- Reader 재생속도/이어읽기 확인
- 프리미엄 아이콘/스플래시 반영
- stable tag 백업 후 빌드
