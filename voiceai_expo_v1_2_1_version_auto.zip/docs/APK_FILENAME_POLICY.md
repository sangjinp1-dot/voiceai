
# APK 파일명 정책

APK 파일명은 반드시 앱 버전을 포함합니다.

예:

```text
SangjinVoiceAI_v1.2.1.apk
```

EAS Build 결과물 다운로드 후 파일명을 아래 형식으로 보관하세요.

```bash
mv app-release.apk SangjinVoiceAI_v1.2.1.apk
```

버전 확인:

```bash
npm run version:show
```
