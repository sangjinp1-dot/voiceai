
# APK 빌드 전 버전 자동 증가 정책

## 현재 반영 버전

- app.json version: 1.2.1
- android.versionCode: 13
- package.json version: 1.2.1
- APK 파일명 규칙: SangjinVoiceAI_v1.2.1.apk

## 필수 규칙

새 APK를 만들기 전 반드시 버전을 증가시켜야 합니다.

금지:
- 같은 version으로 APK 재생성
- 같은 versionCode로 APK 재생성
- 설정 화면 버전과 app.json 버전 불일치

## 자동 증가 명령

```bash
npm run bump:patch
npm run version:show
```

APK 빌드:

```bash
eas build -p android --profile preview
```

## 앱 내부 버전 표시

`App.js`에서 `app.json`을 import합니다.

표시값:
- appInfo.expo.version
- appInfo.expo.android.versionCode
- appInfo.expo.extra.apkFileName

따라서 app.json 버전과 설정 화면 버전이 자동으로 일치합니다.
