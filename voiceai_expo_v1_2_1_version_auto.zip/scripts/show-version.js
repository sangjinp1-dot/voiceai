
const app = require("../app.json");
const version = app.expo.version;
const versionCode = app.expo.android.versionCode;
const apkFileName = app.expo.extra?.apkFileName || `SangjinVoiceAI_v${version}.apk`;

console.log(`App version: ${version}`);
console.log(`Android versionCode: ${versionCode}`);
console.log(`APK filename: ${apkFileName}`);
