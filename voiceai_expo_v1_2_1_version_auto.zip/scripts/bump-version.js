
const fs = require("fs");

function readJson(path) {
  return JSON.parse(fs.readFileSync(path, "utf8"));
}
function writeJson(path, data) {
  fs.writeFileSync(path, JSON.stringify(data, null, 2) + "\n");
}
function bumpSemver(version, mode) {
  const parts = version.split(".").map(Number);
  let major = parts[0] || 1;
  let minor = parts[1] || 0;
  let patch = parts[2] || 0;
  if (mode === "major") {
    major += 1; minor = 0; patch = 0;
  } else if (mode === "minor") {
    minor += 1; patch = 0;
  } else {
    patch += 1;
  }
  return `${major}.${minor}.${patch}`;
}

const mode = process.argv[2] || "patch";
const app = readJson("app.json");
const pkg = readJson("package.json");

const oldVersion = app.expo.version || pkg.version || "1.0.0";
const oldCode = Number(app.expo.android?.versionCode || 1);
const newVersion = bumpSemver(oldVersion, mode);
const newCode = oldCode + 1;
const apkFileName = `SangjinVoiceAI_v${newVersion}.apk`;

app.expo.version = newVersion;
app.expo.android = app.expo.android || {};
app.expo.android.versionCode = newCode;
app.expo.extra = app.expo.extra || {};
app.expo.extra.appVersion = newVersion;
app.expo.extra.versionCode = newCode;
app.expo.extra.apkFileName = apkFileName;

pkg.version = newVersion;

writeJson("app.json", app);
writeJson("package.json", pkg);
writeJson("VERSION_BUILD_INFO.json", {
  version: newVersion,
  versionCode: newCode,
  apkFileName,
  updatedAt: new Date().toISOString()
});

console.log(`✅ Version bumped: ${oldVersion}(${oldCode}) → ${newVersion}(${newCode})`);
console.log(`✅ APK filename: ${apkFileName}`);
