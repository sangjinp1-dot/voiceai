# VoiceAI Expo v1.2.0 보완판

요청한 10개 필수 보완사항 반영 버전입니다.

## 반영 완료
- 설정 화면: OpenAI 제거, Gemini/ElevenLabs 구조
- 오류 메시지: 401 raw json 대신 사용자 친화 안내
- STT: Google Speech-to-Text, ko-KR, latest_long, 자동 문장부호, retry/timeout
- ElevenLabs: eleven_multilingual_v2, stability/similarity/style/speaker boost 적용
- Voice Clone: Voice 탭, 음성 녹음/업로드, ElevenLabs clone API, 내 목소리 TTS 테스트
- Reader: 문장/문단 자동 분리, 재생속도, 이어읽기, 위치 복구
- 안정성: timeout, retry, 앱 재실행 복구
- 보안: expo-secure-store 사용
- 출시급 UI: 프리미엄 아이콘, 스플래시, 파형 애니메이션, 다크 UI
- APK/AAB: EAS preview/production 구조

## 실행
```bash
npm install
npx expo start
```

## APK 빌드
```bash
eas build -p android --profile preview
```

## Production AAB
```bash
eas build -p android --profile production
```

## 주의
Google Speech-to-Text는 녹음 포맷에 민감합니다. 실제 출시형은 서버에서 m4a/mp3/wav 변환 후 STT 호출하는 구조가 가장 안정적입니다.
